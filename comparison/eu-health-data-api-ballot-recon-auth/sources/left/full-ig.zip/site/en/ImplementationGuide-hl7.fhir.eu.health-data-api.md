# Resource EU Health Data API



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "hl7.fhir.eu.health-data-api",
  "language" : "en",
  "url" : "http://hl7.eu/fhir/health-data-api/ImplementationGuide/hl7.fhir.eu.health-data-api",
  "version" : "1.0.0-ballot",
  "name" : "EuHealthDataApi",
  "title" : "EU Health Data API",
  "status" : "draft",
  "date" : "2026-10-23T12:03:51+02:00",
  "publisher" : "HL7 Europe",
  "contact" : [{
    "name" : "HL7 Europe",
    "telecom" : [{
      "system" : "url",
      "value" : "http://hl7.eu"
    }]
  }],
  "description" : "This Implementation Guide defines FHIR-based APIs for accessing and exchanging health data in the European Health Data Space (EHDS). It composes existing IHE and HL7 specifications — MHD for document exchange, SMART Backend Services for authorization, PDQm for patient matching, and IPA for resource access — into a unified conformance target for EHR systems across Europe.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "150",
      "display" : "Europe"
    }]
  }],
  "copyright" : "Copyright HL7 Europe. Licensed under Creative Commons public domain (CC0 1.0).",
  "packageId" : "hl7.fhir.eu.health-data-api",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "hl7_fhir_eu_base",
    "uri" : "http://hl7.eu/fhir/base/ImplementationGuide/hl7.fhir.eu.base",
    "packageId" : "hl7.fhir.eu.base",
    "version" : "2.0.0-ballot"
  },
  {
    "id" : "ihe_iti_pdqm",
    "uri" : "https://profiles.ihe.net/ITI/PDQm/ImplementationGuide/ihe.iti.pdqm",
    "packageId" : "ihe.iti.pdqm",
    "version" : "3.2.x"
  },
  {
    "id" : "ihe_iti_mhd",
    "uri" : "https://profiles.ihe.net/ITI/MHD/ImplementationGuide/ihe.iti.mhd",
    "packageId" : "ihe.iti.mhd",
    "version" : "4.2.x"
  },
  {
    "id" : "hl7_fhir_uv_ipa",
    "uri" : "http://hl7.org/fhir/uv/ipa/ImplementationGuide/hl7.fhir.uv.ipa",
    "packageId" : "hl7.fhir.uv.ipa",
    "version" : "1.1.x"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ballot"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "default-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "default-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "default-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "default-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "usage-stats-opt-out"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "0.1.0-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.eu/fhir/health-data-api/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ballot"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "default-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "default-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "default-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "default-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "usage-stats-opt-out"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "0.1.0-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.eu/fhir/health-data-api/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-document-access-provider-actor-eu-api.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/document-access-provider-actor-eu-api"
      },
      "name" : "EEHRxF Document Access Provider",
      "description" : "The Document Access Provider actor provides access to EEHRxF FHIR Documents by receiving\ndocuments from Document Publishers and serving them to Document Consumers. This composite\nactor groups MHD Document Recipient, MHD Document Responder, PDQm Patient Demographics\nSupplier, and IUA Authorization Server/Resource Server.\n\nSee [Document Access Provider CapabilityStatement](CapabilityStatement-document-access-provider-eu-api.html)\nfor technical requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-document-access-provider-submission-option-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/document-access-provider-submission-option-eu-api"
      },
      "name" : "EEHRxF Document Access Provider - Document Submission Option",
      "description" : "CapabilityStatement for the Document Submission Option on the EEHRxF Document Access Provider.\n\nThis option enables the Access Provider to receive documents from external Document\nPublishers via [ITI-105 Simplified Publish](https://profiles.ihe.net/ITI/MHD/ITI-105.html).\n\nSystems implementing this option:\n- SHALL also implement the base [Document Access Provider](CapabilityStatement-document-access-provider-eu-api.html) capabilities\n- SHALL accept ITI-105 transactions from authorized Document Publishers\n- SHALL make received documents available via ITI-67 and ITI-68\n- SHALL validate documents against EEHRxF content profiles\n\nThis option is REQUIRED when acting as a delegated access provider for external\nDocument Publishers (e.g., integration engines, national infrastructure).\n\n### Actor Grouping\n\nAdds to base Document Access Provider:\n- [MHD Document Recipient](https://profiles.ihe.net/ITI/MHD/1331_actors_and_transactions.html) - Simplified Publish Option ([CapabilityStatement](https://profiles.ihe.net/ITI/MHD/CapabilityStatement-IHE.MHD.DocumentRecipient.html))\n\n### Transaction\n\n| Transaction | Description | Optionality |\n|-------------|-------------|-------------|\n| ITI-105 Simplified Publish | Accept document publication from Document Publishers | R |\n\n### Security\nSystems SHALL support SMART Backend Services authorization for document submission.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-document-access-provider-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/document-access-provider-eu-api"
      },
      "name" : "EEHRxF Document Access Provider CapabilityStatement",
      "description" : "CapabilityStatement for the EEHRxF Document Access Provider actor. This composite actor\nprovides access to EEHRxF FHIR Documents by serving them to Document Consumers via query APIs.\n\n### Actor Grouping\n\nThis composite actor groups the following IHE actors:\n- [IUA Authorization Server](https://profiles.ihe.net/ITI/IUA/index.html#34112-authorization-server)\n- [IUA Resource Server](https://profiles.ihe.net/ITI/IUA/index.html#34113-resource-server)\n- [PDQm Patient Demographics Supplier](https://profiles.ihe.net/ITI/PDQm/volume-1.html)\n- [MHD Document Responder](https://profiles.ihe.net/ITI/MHD/1331_actors_and_transactions.html)\n\n### Transactions\n\n| Transaction | Description | Optionality |\n|-------------|-------------|-------------|\n| ITI-67 Find Document References | Respond to document metadata queries from Document Consumers | R |\n| ITI-68 Retrieve Document | Serve document content to Document Consumers | R |\n| ITI-78 Patient Demographics Query | Respond to patient demographics queries | O |\n| Get Access Token | Issue authorization tokens to clients | R |\n\n### Security\nSystems SHALL support SMART Backend Services authorization for all transactions.\n\n### Document Submission Option\nTo accept document publication from external Document Publishers, implement the\n[Document Submission Option](CapabilityStatement-document-access-provider-submission-option-eu-api.html).\n\n### Deployment\nThe Document Access Provider may be grouped with Document Publisher, in which case\ndocument publication is internal. See the\n[grouped Document Publisher/Access Provider CapabilityStatement](CapabilityStatement-document-publisher-access-provider-eu-api.html)\nfor this deployment pattern.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-document-consumer-actor-eu-api.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/document-consumer-actor-eu-api"
      },
      "name" : "EEHRxF Document Consumer",
      "description" : "The Document Consumer actor consumes EEHRxF FHIR Documents by querying a Document Access\nProvider. This composite actor groups MHD Document Consumer, PDQm Patient Demographics\nConsumer, and IUA Authorization Client.\n\nSee [Document Consumer CapabilityStatement](CapabilityStatement-document-consumer-eu-api.html)\nfor technical requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-document-consumer-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/document-consumer-eu-api"
      },
      "name" : "EEHRxF Document Consumer CapabilityStatement",
      "description" : "CapabilityStatement for the EEHRxF Document Consumer actor. This composite actor\nconsumes EEHRxF FHIR Documents by querying a Document Access Provider.\n\n### Actor Grouping\n\nThis composite actor groups the following IHE actors:\n- [IUA Authorization Client](https://profiles.ihe.net/ITI/IUA/index.html#34111-authorization-client)\n- [PDQm Patient Demographics Consumer](https://profiles.ihe.net/ITI/PDQm/volume-1.html)\n- [MHD Document Consumer](https://profiles.ihe.net/ITI/MHD/1331_actors_and_transactions.html)\n\n### Transactions\n\n| Transaction | Description | Optionality |\n|-------------|-------------|-------------|\n| ITI-67 Find Document References | Query for document metadata from Document Access Provider | R |\n| ITI-68 Retrieve Document | Retrieve document content from Document Access Provider | R |\n| ITI-78 Patient Demographics Query | Query for patient demographics to establish patient context | R |\n| Get Access Token | Obtain authorization token for API access | R |\n\n### Security\nSystems SHALL support SMART Backend Services authorization for all transactions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-document-priority-category-eu-api.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/document-priority-category-eu-api"
      },
      "name" : "EEHRxF Document Priority Category CodeSystem",
      "description" : "CodeSystem for priority document categories in EEHRxF as the document categories as defined in the EHDS regulation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-document-publisher-actor-eu-api.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/document-publisher-actor-eu-api"
      },
      "name" : "EEHRxF Document Publisher",
      "description" : "The Document Publisher actor produces EEHRxF FHIR Documents and publishes them to a\nDocument Access Provider. This composite actor groups MHD Document Source, PDQm\nPatient Demographics Consumer, and IUA Authorization Client.\n\nSee [Document Publisher CapabilityStatement](CapabilityStatement-document-publisher-eu-api.html)\nfor technical requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-document-publisher-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/document-publisher-eu-api"
      },
      "name" : "EEHRxF Document Publisher CapabilityStatement",
      "description" : "CapabilityStatement for the EEHRxF Document Publisher actor. This composite actor produces\nEEHRxF FHIR Documents and publishes them to a Document Access Provider.\n\n### Actor Grouping\n\nThis composite actor groups the following IHE actors:\n- [IUA Authorization Client](https://profiles.ihe.net/ITI/IUA/index.html#34111-authorization-client)\n- [PDQm Patient Demographics Consumer](https://profiles.ihe.net/ITI/PDQm/volume-1.html)\n- [MHD Document Source](https://profiles.ihe.net/ITI/MHD/1331_actors_and_transactions.html)\n\n### Transactions\n\n| Transaction | Description | Optionality |\n|-------------|-------------|-------------|\n| ITI-105 Simplified Publish | Submit document with embedded content to a Document Access Provider | R |\n| ITI-78 Patient Demographics Query | Query for patient demographics to establish patient context | R |\n| Get Access Token | Obtain authorization token for API access | R |\n\n### Security\nSystems SHALL support SMART Backend Services authorization for all transactions.\n\n### Deployment\nThe Document Publisher may be grouped with Document Access Provider, in which case the\nITI-105 transaction becomes internal and is not exposed externally. See the\n[grouped Document Publisher/Access Provider CapabilityStatement](CapabilityStatement-document-publisher-access-provider-eu-api.html)\nfor this deployment pattern.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-document-type-eu-api.html"
      }],
      "reference" : {
        "reference" : "ValueSet/document-type-eu-api"
      },
      "name" : "EEHRxF Document Type ValueSet",
      "description" : "Document type codes for clinical precision in document identification.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-document-type-discharge-report-eu-api.html"
      }],
      "reference" : {
        "reference" : "ValueSet/document-type-discharge-report-eu-api"
      },
      "name" : "EEHRxF Document Type ValueSet for Discharge Reports",
      "description" : "ValueSet for specific document types within the Discharge Report priority category.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-document-type-laboratory-report-eu-api.html"
      }],
      "reference" : {
        "reference" : "ValueSet/document-type-laboratory-report-eu-api"
      },
      "name" : "EEHRxF Document Type ValueSet for Laboratory Reports",
      "description" : "ValueSet for specific document types within the Laboratory Report priority category.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-document-type-medical-imaging-eu-api.html"
      }],
      "reference" : {
        "reference" : "ValueSet/document-type-medical-imaging-eu-api"
      },
      "name" : "EEHRxF Document Type ValueSet for Medical Imaging",
      "description" : "ValueSet for specific document types within the Medical Imaging priority category.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-document-type-patient-summary-eu-api.html"
      }],
      "reference" : {
        "reference" : "ValueSet/document-type-patient-summary-eu-api"
      },
      "name" : "EEHRxF Document Type ValueSet for Patient Summaries",
      "description" : "ValueSet for specific document types within the Patient Summary priority category.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-document-publisher-access-provider-actor-eu-api.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/document-publisher-access-provider-actor-eu-api"
      },
      "name" : "EEHRxF Grouped Document Publisher/Access Provider",
      "description" : "The grouped Document Publisher/Access Provider actor represents a deployment where document\nproduction and access provision are co-located in the same system. In this configuration,\ndocument submission (ITI-105) is internal and only document query/retrieval (ITI-67, ITI-68)\nis exposed externally.\n\nThis is common for hospital EHR systems that produce and serve their own documents.\n\nSee [Grouped Document Publisher/Access Provider CapabilityStatement](CapabilityStatement-document-publisher-access-provider-eu-api.html)\nfor technical requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-document-publisher-access-provider-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/document-publisher-access-provider-eu-api"
      },
      "name" : "EEHRxF Grouped Document Publisher/Access Provider CapabilityStatement",
      "description" : "CapabilityStatement for the grouped EEHRxF Document Publisher and Document Access Provider\nactors. This represents a deployment where document production and access provision are\nco-located in the same system.\n\n### Deployment Pattern\n\nThis CapabilityStatement applies when:\n- An EHR system both produces documents AND provides access to them\n- Document publication is handled internally\n- External clients only need to query and retrieve documents\n\nIn this grouped deployment, document publication is internal to the system and not exposed\nexternally. The external API provides only document discovery (ITI-67) and retrieval (ITI-68)\ncapabilities.\n\n### Actor Grouping\n\nThis grouped actor combines:\n- **Document Publisher** (internal) - Produces and stores documents internally\n- **Document Access Provider** (external-facing) - Serves documents to Document Consumers\n\nThe underlying IHE actors are:\n- [IUA Authorization Server](https://profiles.ihe.net/ITI/IUA/index.html#34112-authorization-server)\n- [IUA Resource Server](https://profiles.ihe.net/ITI/IUA/index.html#34113-resource-server)\n- [PDQm Patient Demographics Supplier](https://profiles.ihe.net/ITI/PDQm/volume-1.html)\n- [MHD Document Responder](https://profiles.ihe.net/ITI/MHD/1331_actors_and_transactions.html)\n\nNote: MHD Document Recipient is not listed because publication is internal.\n\n### External Transactions\n\n| Transaction | Description | Optionality |\n|-------------|-------------|-------------|\n| ITI-67 Find Document References | Respond to document metadata queries from Document Consumers | R |\n| ITI-68 Retrieve Document | Serve document content to Document Consumers | R |\n| ITI-78 Patient Demographics Query | Respond to patient demographics queries | O |\n| Get Access Token | Issue authorization tokens to clients | R |\n\n### Security\nSystems SHALL support SMART Backend Services authorization for all transactions.\n\n### When to Use This CapabilityStatement\n\nUse this CapabilityStatement when implementing:\n- Hospital EHR systems that produce and serve their own documents\n- Regional health information exchanges with integrated document repositories\n- Any system where document creation and access are tightly coupled\n\nFor systems that need to receive documents from external sources, use the\n[Document Access Provider with Document Submission Option](CapabilityStatement-document-access-provider-submission-option-eu-api.html).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-document-reference-category-type-eu-api.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/document-reference-category-type-eu-api"
      },
      "name" : "EEHRxF MHD DocumentReference ConceptMap",
      "description" : "mapping from the EHDS regulatory priority categories to the LOINC document category codes for clinical precision in document identification.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-resource-access-provider-actor-eu-api.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/resource-access-provider-actor-eu-api"
      },
      "name" : "EEHRxF Resource Access Provider",
      "description" : "The Resource Access Provider actor provides access to FHIR resources following IPA patterns.\nThis enables direct resource access complementing document-based exchange.\nThis composite actor groups IPA Server, PDQm Patient Demographics\nSupplier, and IUA Authorization Server/Resource Server.\n\nSee [Resource Access Provider CapabilityStatement](CapabilityStatement-resource-access-provider-eu-api.html)\nfor technical requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-resource-access-provider-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/resource-access-provider-eu-api"
      },
      "name" : "EEHRxF Resource Access Provider CapabilityStatement",
      "description" : "CapabilityStatement for the EEHRxF Resource Access Provider actor. This actor serves\nclinical data resources following the International Patient Access (IPA) patterns.\n\nThis CapabilityStatement defines the capabilities for systems providing direct resource\naccess (beyond document-based exchange) in the EU EHR Exchange Format (EEHRxF) ecosystem.\nIt inherits patterns from:\n- **IPA (International Patient Access)**: Resource profiles and search parameter patterns\n\n### Resource Flexibility (IPA Alignment)\n\nFollowing IPA's approach, servers are not required to support all clinical resources listed\nbelow. Servers MAY choose which resources to implement based on their capabilities and use\ncases. The only required resource is Patient (for lookup context). This flexibility\nencourages partial implementations, allowing more servers to participate even if they only\nsupport EU Core for certain resource types.\n\n**Required**: Patient (for lookup context)\n**Recommended (choose based on capabilities)**:\n- Practitioner, Organization: Reference resolution\n- Condition, AllergyIntolerance: Patient safety data\n- Observation, DiagnosticReport: Clinical results\n- ImagingStudy: Imaging results\n- MedicationRequest, MedicationDispense, MedicationStatement: Medication data\n- Immunization: Vaccination records\n- Encounter: Visit context\n\nThe server's CapabilityStatement declares which resources are actually supported.\n\n### Security\nSystems SHALL support SMART Backend Services authorization for all transactions.\n\n### Profile Inheritance\nResources SHOULD conform to EU Core profiles where available.\n\n### Search Parameter Combinations\nWhere a resource declares search parameter combinations, the SHALL combinations follow IPA,\nwith additions from IHE QEDm where the IPA has no requirement (DiagnosticReport, Encounter).\nData type-specific implementation guides MAY extend these requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-resource-consumer-actor-eu-api.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/resource-consumer-actor-eu-api"
      },
      "name" : "EEHRxF Resource Consumer",
      "description" : "The Resource Consumer actor queries for clinical data resources from a Resource Access\nProvider following IPA patterns. This composite actor groups IPA Client,\nPDQm Patient Demographics Consumer, and IUA Authorization Client.\n\nSee [Resource Consumer CapabilityStatement](CapabilityStatement-resource-consumer-eu-api.html)\nfor technical requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-resource-consumer-eu-api.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/resource-consumer-eu-api"
      },
      "name" : "EEHRxF Resource Consumer CapabilityStatement",
      "description" : "CapabilityStatement for the EEHRxF Resource Consumer actor. This actor queries for\nclinical data resources following the International Patient Access (IPA) patterns.\n\nThis CapabilityStatement defines the requirements for systems consuming direct resource\naccess (beyond document-based exchange) in the EU EHR Exchange Format (EEHRxF) ecosystem.\nIt inherits patterns from:\n- **IPA (International Patient Access)**: Resource profiles and search parameter patterns\n\n### Resource Flexibility (IPA Alignment)\n\nFollowing IPA's approach, clients are not required to consume all clinical resources listed\nbelow. Clients MAY choose which resources to query based on their needs and the server's\ndeclared capabilities. The only required capability is Patient lookup. This flexibility\nallows clients to implement targeted use cases without requiring support for all resource types.\n\n**Required**: Patient (for lookup context)\n**Optional (request based on needs and server support)**:\n- Practitioner, Organization: Reference resolution\n- Condition, AllergyIntolerance: Patient safety data\n- Observation, DiagnosticReport: Clinical results\n- ImagingStudy: Imaging results\n- MedicationRequest, MedicationDispense, MedicationStatement: Medication data\n- Immunization: Vaccination records\n- Encounter: Visit context\n\nClients should check the server's CapabilityStatement to discover which resources are available.\n\n### Security\nSystems SHALL support SMART Backend Services authorization for all transactions.\n\n### Profile Inheritance\nConsumers SHOULD expect resources conforming to EU Core profiles where available.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-example-documentreference-eps.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/example-documentreference-eps"
      },
      "name" : "Example - European Patient Summary DocumentReference",
      "description" : "Example DocumentReference showing an EPS document with EEHRxF category coding.\n\nThis example demonstrates the recommended search strategy:\n- `category` = Patient-Summaries (EHDS priority category for coarse filtering)\n- `type` = 60591-5 (LOINC code for clinical precision)\n\n**Example query to find this document by priority category:**\n```\nGET [base]/DocumentReference?patient=Patient/example-patient&category=https://euridice.ec.europa.eu/fhir/eehrxf/CodeSystem/document-priority-category-eu-api|Patient-Summaries\n```\n\n**Example query to find this document by type:**\n```\nGET [base]/DocumentReference?patient=Patient/example-patient&type=http://loinc.org|60591-5\n```",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-example-documentreference-hdr.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/example-documentreference-hdr"
      },
      "name" : "Example - Hospital Discharge Report DocumentReference",
      "description" : "Example DocumentReference for a hospital discharge report.\n\n**Example query:**\n```\nGET [base]/DocumentReference?patient.identifier=http://example.org/national-id|123456789&type=http://loinc.org|18842-5\n```",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-example-documentreference-imaging-report.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/example-documentreference-imaging-report"
      },
      "name" : "Example - Imaging Report DocumentReference",
      "description" : "Example DocumentReference for a diagnostic imaging report.\n\n**Example query:**\n```\nGET [base]/DocumentReference?patient.identifier=http://example.org/national-id|123456789&type=http://loinc.org|85430-7\n```",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-example-documentreference-imaging-manifest-kos.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/example-documentreference-imaging-manifest-kos"
      },
      "name" : "Example - Imaging Study Manifest (DICOM KOS)",
      "description" : "Example DocumentReference for a DICOM KOS-encoded imaging study manifest.\n\nThis is one half of the dual-DocumentReference pattern for imaging manifests.\nThe DICOM KOS DocumentReference is linked to its FHIR manifest counterpart\nvia `relatesTo.code = transforms`.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-example-documentreference-imaging-manifest-fhir.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/example-documentreference-imaging-manifest-fhir"
      },
      "name" : "Example - Imaging Study Manifest (FHIR)",
      "description" : "Example DocumentReference for a FHIR-encoded imaging study manifest.\n\nThis is one half of the dual-DocumentReference pattern for imaging manifests.\nThe FHIR manifest DocumentReference is linked to its DICOM KOS counterpart\nvia `relatesTo.code = transforms`.\n\n**Example query to find imaging manifests by type:**\n```\nGET [base]/DocumentReference?patient.identifier=http://example.org/national-id|123456789&type=http://loinc.org|18748-4&status=current\n```",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-example-documentreference-laboratory.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/example-documentreference-laboratory"
      },
      "name" : "Example - Laboratory Report DocumentReference",
      "description" : "Example DocumentReference for a laboratory report.\n\n**Example query:**\n```\nGET [base]/DocumentReference?patient.identifier=http://example.org/national-id|123456789&type=http://loinc.org|11502-2\n```",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-example-capabilitystatement-document-access-provider.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/example-capabilitystatement-document-access-provider"
      },
      "name" : "Example: Document Access Provider Supporting EPS and Laboratory",
      "description" : "**Example** CapabilityStatement for a Document Access Provider that supports\nEuropean Patient Summaries and Laboratory Reports.\n\nShows how a deployment declares actor conformance via `instantiates` and\ncontent IG support via `implementationGuide`.\n\nSee [Capability Discovery](capability-discovery.html) for guidance.",
      "exampleBoolean" : true
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "background.html"
        }],
        "nameUrl" : "background.html",
        "title" : "Background",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "regulatoryAnchors.html"
          }],
          "nameUrl" : "regulatoryAnchors.html",
          "title" : "Regulatory Anchors",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "actors.html"
          }],
          "nameUrl" : "actors.html",
          "title" : "Actors and Transactions",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "priority-categories.html"
          }],
          "nameUrl" : "priority-categories.html",
          "title" : "Priority Categories",
          "generation" : "markdown",
          "page" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "priority-area-eps.html"
            }],
            "nameUrl" : "priority-area-eps.html",
            "title" : "Patient Summary (EPS)",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "priority-area-mpd.html"
            }],
            "nameUrl" : "priority-area-mpd.html",
            "title" : "ePrescription / eDispensation (MPD)",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "priority-area-laboratory.html"
            }],
            "nameUrl" : "priority-area-laboratory.html",
            "title" : "Medical Test Results (Laboratory)",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "priority-area-imaging-report.html"
            }],
            "nameUrl" : "priority-area-imaging-report.html",
            "title" : "Medical Imaging Report",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "priority-area-imaging-manifest.html"
            }],
            "nameUrl" : "priority-area-imaging-manifest.html",
            "title" : "Medical Imaging Manifest",
            "generation" : "markdown"
          },
          {
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "priority-area-hdr.html"
            }],
            "nameUrl" : "priority-area-hdr.html",
            "title" : "Hospital Discharge Report",
            "generation" : "markdown"
          }]
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "member-state-architectures.html"
          }],
          "nameUrl" : "member-state-architectures.html",
          "title" : "Member State Architectures",
          "generation" : "markdown",
          "page" : [{
            "extension" : [{
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "fhir-documents-vs-resources.html"
            }],
            "nameUrl" : "fhir-documents-vs-resources.html",
            "title" : "FHIR Documents and Resources",
            "generation" : "markdown"
          }]
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "background-xds-fhir.html"
          }],
          "nameUrl" : "background-xds-fhir.html",
          "title" : "Relationship to XDS/FHIR Document Sharing",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "changes.html"
          }],
          "nameUrl" : "changes.html",
          "title" : "Change Log",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "open-issues.html"
          }],
          "nameUrl" : "open-issues.html",
          "title" : "Open Issues",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "functional.html"
        }],
        "nameUrl" : "functional.html",
        "title" : "Functional Requirements",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "capability-discovery.html"
          }],
          "nameUrl" : "capability-discovery.html",
          "title" : "Capability Discovery",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "authorization.html"
          }],
          "nameUrl" : "authorization.html",
          "title" : "Authorization",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "patient-match.html"
          }],
          "nameUrl" : "patient-match.html",
          "title" : "Patient Lookup",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "document-exchange.html"
          }],
          "nameUrl" : "document-exchange.html",
          "title" : "Document Exchange",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "resource-access.html"
          }],
          "nameUrl" : "resource-access.html",
          "title" : "Resource Access",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "resourceExchange.html"
          }],
          "nameUrl" : "resourceExchange.html",
          "title" : "Resource Exchange Patterns",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "implementation.html"
        }],
        "nameUrl" : "implementation.html",
        "title" : "Implementation",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "example-patient-summary.html"
          }],
          "nameUrl" : "example-patient-summary.html",
          "title" : "Retrieve a European Patient Summary",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "usecase-cross-border-ncp.html"
          }],
          "nameUrl" : "usecase-cross-border-ncp.html",
          "title" : "Cross-Border Exchange via NCP",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "usecase-health-professional-portal.html"
          }],
          "nameUrl" : "usecase-health-professional-portal.html",
          "title" : "Health Professional Access Service",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "usecase-health-data-portal.html"
          }],
          "nameUrl" : "usecase-health-data-portal.html",
          "title" : "Health Data Access Service",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "usecase-wellness-app.html"
          }],
          "nameUrl" : "usecase-wellness-app.html",
          "title" : "Wellness Apps",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "usecase-cross-org.html"
          }],
          "nameUrl" : "usecase-cross-org.html",
          "title" : "Cross-Organization via National Infrastructure",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "usecase-provider-internal-exchange.html"
          }],
          "nameUrl" : "usecase-provider-internal-exchange.html",
          "title" : "Provider-Internal Exchange",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "ehr-system-composition.html"
          }],
          "nameUrl" : "ehr-system-composition.html",
          "title" : "EHR System Composition Patterns",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "about.html"
        }],
        "nameUrl" : "about.html",
        "title" : "About",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "contributors.html"
          }],
          "nameUrl" : "contributors.html",
          "title" : "Authors and contributors",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "copyright.html"
          }],
          "nameUrl" : "copyright.html",
          "title" : "Copyright",
          "generation" : "markdown"
        }]
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
