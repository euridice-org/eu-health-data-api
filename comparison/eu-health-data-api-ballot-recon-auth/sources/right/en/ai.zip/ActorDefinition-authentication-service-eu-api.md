# Authentication Service - EU Health Data API v1.0.0-ballot

## ActorDefinition: Authentication Service 

